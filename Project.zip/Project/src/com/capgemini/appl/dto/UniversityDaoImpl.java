package com.capgemini.appl.dto;

import java.sql.Connection; 
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.appl.dao.Application;
import com.capgemini.appl.dao.ProgramsScheduled;
import com.capgemini.appl.exception.UniversityAdmissionException;
import com.capgemini.appl.util.JndiUtil;

public class UniversityDaoImpl  implements UniversityDao{

	private JndiUtil util;
	public UniversityDaoImpl() throws UniversityAdmissionException {
		util= new JndiUtil();
	}

	@Override
	public List<ProgramsScheduled> showProgramInfo(String programName,Date startdate,Date enddate)
			throws UniversityAdmissionException {
		
		Connection conn=null;
		PreparedStatement pstm=null;
		ProgramsScheduled prog = new ProgramsScheduled(); 
		List<ProgramsScheduled> progList = new ArrayList<ProgramsScheduled>();
		
		String qry = "SELECT Scheduled_program_id,ProgramName  FROM Programs_Scheduled where((ProgramName=?) AND (start_date>=?) AND (end_date<=?))";
		try {
			conn = util.getConnection();
			pstm=conn.prepareStatement(qry);
			
			pstm.setString(1, programName);
			pstm.setDate(2, startdate);
			pstm.setDate(3, enddate);
			ResultSet rs = pstm.executeQuery();
			
			while(rs.next()){
				
				prog.setScheduled_program_id(rs.getInt("Scheduled_program_id"));
				prog.setProgramName(rs.getString("ProgramName"));
				progList.add(prog);
				
			}
			
		
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new UniversityAdmissionException("Problem occured while showing program Details",e);
		}
		finally{
			try{
				
				pstm.close();
				conn.close();
				
			}catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();	
		}
		}
		
		return progList;
	}

}
