package com.capgemini.appl.dto;

public interface UniversityDto {

}
