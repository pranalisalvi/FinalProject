package com.capgemini.appl.service;

import java.sql.Date;
import java.util.List;

import com.capgemini.appl.dao.Application;
import com.capgemini.appl.dao.ProgramsScheduled;
import com.capgemini.appl.exception.UniversityAdmissionException;

public interface UniversityService {

	
	public List<ProgramsScheduled> showProgramInfo(String programName,Date startdate,Date enddate) throws UniversityAdmissionException;
	
}
